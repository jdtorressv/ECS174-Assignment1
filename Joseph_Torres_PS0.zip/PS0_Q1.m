% A is a 100x100 matrix of randomly generated uniformly distributed doubles
load PS0_A.mat 
B = 1:10000; 
figure(1);
plot(B, sort(A(:), 'descend')); 
figure(2); 
histogram(A(:), 10);
Z = A(51:100, 1:50);
figure(3); 
imagesc(Z); 
W = A - mean(A(:)); 
figure(4); 
imagesc(W); 
Y = zeros(100, 100, 3); 
ind = find(A > mean(A(:))); 
Y(ind) = 255;
figure(5); 
imshow(Y);

