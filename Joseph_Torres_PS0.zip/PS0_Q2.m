function PS0_Q2()
A = imread('918.jpg');
subplot(3,2,1); 
grayscale = colorToGray(A); 
subplot(3,2,2); 
negIm(grayscale); 
subplot(3,2,3); 
flipped = flipLeftToRight(A); 
subplot(3,2,4); 
swapRedBlue(A); 
subplot(3,2,5); 
averageWithMirror(A, flipped); 
subplot(3,2,6); 
addRand(grayscale); 
end 

function result = colorToGray(A)
dimArr = size(A); 
result = uint8(ones(dimArr(1), dimArr(2)) .* mean(A,3));%./255.0;  
imshow(result); 
end 

function negIm(A)
A = 255 - A;
imshow(A); 
end

function flipped = flipLeftToRight(A)
flipped = A(:,end:-1:1,:);
imshow(flipped); 
end

function swapRedBlue(A)
swapped = A(:,:,end:-1:1); 
imshow(swapped); 
end

function averageWithMirror(A,B)
average = uint8((A+B)./2.0);
imshow(average); 
end

function addRand(A)
dim = size(A);
B = double(A) + randi([-255,255],dim(1),dim(2));
C = min(B,255); 
D = max(C,0); 
imshow(D./255.0); 
end
